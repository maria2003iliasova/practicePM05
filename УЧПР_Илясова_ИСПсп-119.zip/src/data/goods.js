import sup from "../images/sup.png"
import mohito from "../images/mohito.png"
import icecream from "../images/icecream.png"

export default {
    goods: [
        { 
            id: 1,
            img: sup,
            name: "Суп",
            price: 350,
            hasInStock: true,
            added: 12342,
            category: "Горячее",
            description: "Состав"
        },
        { 
            id: 2,
            img: mohito,
            name: "Мохито",
            price: 200,
            hasInStock: true,
            added: 12343,
            category: "Напитки",
            description: "Состав"
        },
        { 
            id: 3,
            img: icecream,
            name: "Мороженое",
            price: 180,
            hasInStock: true,
            added: 12344,
            category: "Десерты",
            description: "Состав"
        },
    ],
};