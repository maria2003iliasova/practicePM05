import { Button, Card, CardImg } from "react-bootstrap";

import { useParams } from "react-router-dom";

import goodsData from "../data/goods";

function Product() {
    let { id } = useParams();
    id = +id;

    const good = goodsData.goods.filter((el) => el.id === id)[0];

    if (!good) {
        return <div>Товар не найден</div>;
    }

    const addToCart = () => {
        const inCart = JSON.parse(localStorage.getItem("cart") || "{}");
        inCart[id] = (inCart[id] || 0) + 1;
        localStorage.setItem("cart", JSON.stringify(inCart));
    };

    return (
        <Card style={{ margin: "15px 0 0px 25px", width: 200, boxShadow: "2px 2px 2px 2px gray" }}>
            <Card.Title style={{ textAlign: "center" }}>{good.name}</Card.Title>
            <CardImg src={good.img} />
            <Card.Body style={{ textAlign: "center" }}>
                <b>Цена:</b>{good.price} <br />
                {good.description} <br />
                <Button variant="warning" id="button" onClick={addToCart}>В корзину</Button>
            </Card.Body>
        </Card>
    );
}

export default Product;