import React from "react";
import lk from "../images/lk.png";
import { Row, Col, Accordion } from "react-bootstrap";

function Lk() {
    return (
        <>
            <h1 style={{ textAlign: "center" }}>Личный кабинет</h1>
            <div style={{ marginLeft: "15px"}}>
                <Col sm={3}><img style={{ height: "100px" }} src={lk} alt=" " /><br />
                    <b>Фамилия: </b> Максимов<br />
                    <b>Имя: </b> Максим<br />
                    <b>Отчество: </b> Максимович<br />
                    <b>Дата рождения: </b> 25/05/2001<br />
                    <b>Номер телефона: </b> 8 905 844 66 36
                </Col>
                <Col sm={6}>
                    <b>Заказы</b>
                    <Accordion defaultActiveKey="0">
                        <Accordion.Item eventKey="0">
                            <Accordion.Header>10/12/2022 выполнен</Accordion.Header>
                            <Accordion.Body>
                                Мороженное   1   180<br />
                                Мохито   1   200<br />
                                ИТОГО: 380
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="1">
                            <Accordion.Header>16/11/2022 выполнен</Accordion.Header>
                            <Accordion.Body>
                                Мороженное   2   320<br />
                                ИТОГО: 320
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item eventKey="2">
                            <Accordion.Header>03/09/2022 выполнен</Accordion.Header>
                            <Accordion.Body>
                                Суп   1   350<br />
                                Мохито   2   200<br />
                                ИТОГО: 750
                            </Accordion.Body>
                        </Accordion.Item>
                    </Accordion>
                </Col>
            </div>
        </>
    );
}
export default Lk;