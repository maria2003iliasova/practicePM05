import React from "react";
import Carousel from 'react-bootstrap/Carousel';
import slider1 from "../images/hot_dish.jpg";
import slider2 from "../images/salad.jpg";
import slider3 from "../images/dessert.jpg";

import "./style.css"
import { Container } from "react-bootstrap";

export default function About() {
  return (
    <Container>
      <h1 className="h1">Доставим ещё горячим!</h1>
      <Carousel variant="Dark">
        <Carousel.Item interval={1000}>
          <img className="slider" src={slider1} alt=" " />
          <Carousel.Caption>
            <h3>Многообразие горячих блюд</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={500}>
          <img className="slider" src={slider2} alt=" " />
          <Carousel.Caption>
            <h3>Разнообразные салаты</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img className="slider" src={slider3} alt=" " />
          <Carousel.Caption>
            <h3>Вкусные десерты</h3>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    </Container>
  );
}