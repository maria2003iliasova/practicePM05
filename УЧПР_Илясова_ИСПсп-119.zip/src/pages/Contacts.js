import React from "react";
import { IoMdCall } from "react-icons/io";
import { IoIosMail } from "react-icons/io";
import map from "../images/map.png";

function Contacts() {
    return (
        <>
        <table style={{ margin: "auto"}}>
            <td style={{ verticalAlign: "middle"}}>Адрес: г.Владимир, ул.Чайковского 27 <br/>
                Работаем с 8:00 до 22:00
            </td>
            <td><h1 style={{ textAlign: "center"}}>Где нас найти</h1><br/><img className="slider" src={map} alt=" " /></td>
            <td style={{ verticalAlign: "middle"}}><IoMdCall/>8 (800) 55-36-47<br/>
                <IoMdCall/>8 (800) 56-43-98<br/>
                <IoIosMail/>mia03.03@mail.ru<br/>
                <IoIosMail/>delivery@mail.ru
            </td>
        </table>
        </>
    );
}
export default Contacts;