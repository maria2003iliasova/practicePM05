import { useState, useEffect } from "react";
import { Button } from "react-bootstrap";
import { TbCirclePlus } from "react-icons/tb";
import { TbCircleMinus } from "react-icons/tb";
import GoodCard from "../components/GoodCard";
import goodsData from "../data/goods";

function Cart() {
  const [cartIsLoaded, setCartIsLoaded] = useState(false);
  const [inCart, setInCart] = useState({});

  useEffect(() => {
    setInCart(JSON.parse(localStorage.getItem("cart")));
    setCartIsLoaded(true);
  }, []);

  useEffect(() => {
    if (!cartIsLoaded) return;
    localStorage.setItem("cart", JSON.stringify(inCart));
  }, [inCart]);

  const goods = goodsData.goods.filter(
    (el) => Object.keys(inCart).indexOf(`${el.id}`) !== -1
  );

  const inc = (id) => {
    setInCart((cart) => ({ ...cart, [id]: (cart[id] || 0) + 1 }));
  };

  const dec = (id) => {
    if (inCart[id] === 1) {
      setInCart((inCart) => {
        const returnValue = { ...inCart };
        delete returnValue[id];
        return returnValue;
      });
      return;
    }
    setInCart((inCart) => ({ ...inCart, [id]: (inCart[id] || 0) - 1 }));
  };


  return (
    <>
    <h1 style={{ textAlign: "center"}}>Корзина</h1>
    <div style={{ margin: "15px", display: "flex", flexWrap: "wrap", gap: 10 }}>
      {goods.map((good) => (
        <GoodCard
          key={good.id}
          id={good.id}
          img={good.img}
          name={good.name}
          price={good.price}
        >
          <TbCircleMinus size={28} onClick={() => dec(good.id)}/>
          {inCart[good.id]}
          <TbCirclePlus size={28} onClick={() => inc(good.id)}/>
        </GoodCard>
      ))}
    </div>
    <h1 style={{ textAlign: "left"}}>Итог: 1100</h1><br/>
    <label>Введите пароль:
      <input style={{ margin: "15px"}} type="text" name="name" />
    </label><br/>
    <Button variant="warning" id="button">Оформить заказ</Button>
    </>
  );
}

export default Cart;
