import React from "react";

export default function About() {
    return <div>Быстрая доставка от 30 минут. Меню на любой вкус: пицца, роллы, воки, напитки. Заказывайте недорого горячую вкусную еду!</div>
}