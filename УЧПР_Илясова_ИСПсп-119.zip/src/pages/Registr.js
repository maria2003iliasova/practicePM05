import React from "react";
import Button from 'react-bootstrap/Button';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { Container } from "react-bootstrap";

import "./style.css"

export default function Login() {
    
    const basicSchema = yup.object().shape({
        name: yup.string().typeError('Должно быть строкой').required('Обязательно'),
        surname: yup.string().typeError('Должно быть строкой').required('Обязательно'),
        patronymic: yup.string().typeError('Должно быть строкой'),
        login: yup.string().typeError('Должно быть строкой').required('Обязательно'),
        email: yup.string().email("Email введен не верно ").required('Обязательно'),
        password: yup.string().min(6, { message: "Пароль должен быть строковый и содержать минимум 6 символов" }).required({message: 'Обязательно'}),
        confirmPassword: yup.string().oneOf([yup.ref("password"), null], 'Пароли не совпадают').required('Обязательно'),
        rules: yup.bool().oneOf([true], "Подтверждение на обработку данных").required('Подтверждение на обработку данных'),
    })
    const onSubmit = (v) => {
        console.log(v)
    }
    const { values, errors, touched, handleBlur, handleChange, handleSubmit } = useFormik({
        initialValues: {
            email: "",
            name: "",
            surname: "",
            patronymic: "",
            login: "",
            password: "",
            confirmPassword: "",
            rules: "",
        },
        validationSchema: basicSchema,
        onSubmit
    });
    console.log(errors)
    return (
        <Container>
            <form className="form" onSubmit={handleSubmit} autoComplete="off">
                <h1>Регистрация</h1>
                <div className="form-div">
                    <label htmlFor="name">Имя</label>
                    <input
                        id="name"
                        type="string"
                        placeholder="Введите имя"
                        value={values.name}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.name && touched.name ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.name && touched.name && <p className="error">{errors.name}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="surname">Фамилия</label>
                    <input
                        id="surname"
                        type="string"
                        placeholder="Введите Фамилию"
                        value={values.nsurnameame}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.surname && touched.surname ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.surname && touched.surname && <p className="error">{errors.surname}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="patronymic">Отчество</label>
                    <input
                        id="patronymic"
                        type="string"
                        placeholder="Введите Отчество"
                        value={values.patronymic}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.patronymic && touched.patronymic ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.patronymic && touched.patronymic && <p className="error">{errors.patronymic}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="login">Логин</label>
                    <input
                        id="login"
                        type="string"
                        placeholder="Введите логин"
                        value={values.login}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.login && touched.login ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.login && touched.login && <p className="error">{errors.login}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="email">E-mail</label>
                    <input
                        value={values.email}
                        onChange={handleChange}
                        id="email"
                        type="email"
                        placeholder="Введите почту"
                        onBlur={handleBlur}
                        className={errors.email && touched.email ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.email && touched.email && <p className="error">{errors.email}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="password">Пароль</label>
                    <input
                        id="password"
                        type="password"
                        placeholder="Введите пароль"
                        value={values.password}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.password && touched.password ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.password && touched.password && <p className="error">{errors.password.message}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="confirmPassword">Повторите пароль</label>
                    <input
                        id="confirmPassword"
                        type="password"
                        placeholder="Повторите пароль"
                        value={values.confirmPassword}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.confirmPassword && touched.confirmPassword ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.confirmPassword && touched.confirmPassword && <p className="error">{errors.confirmPassword}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="rules">Согласиле на обработку данных</label>
                    <input
                        id="rules"
                        type="checkbox"
                        placeholder="Согласиле на обработку данных"
                        value={values.rules}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.rules && touched.rules ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.rules && touched.rules && <p className="error">{errors.rules}</p>}
                </div>
                <Button type="submit" variant="warning" id="button">Зарегистрироваться</Button>
            </form>
        </Container>
    )
}