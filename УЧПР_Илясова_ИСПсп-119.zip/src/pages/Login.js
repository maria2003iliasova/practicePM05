import React from "react";
import Button from 'react-bootstrap/Button';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { Container } from "react-bootstrap";

import "./style.css"

export default function Login() {
    const passwordRules = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    const basicSchema = yup.object().shape({
        login: yup.string().typeError('Неверный логин').required('Обязательно'),
        password: yup.string().min(6).matches(passwordRules, { message: "Пароль должен быть строковый" }).required('Обязательно'),
    })
    const onSubmit = (v) => {
        console.log(v)
    }
    const { values, errors, touched, handleBlur, handleChange, handleSubmit } = useFormik({
        initialValues: {
            login: "",
            password: "",
        },
        validationSchema: basicSchema,
        onSubmit
    });
    console.log(errors)
    return (
        <Container>
            <form className="form" onSubmit={handleSubmit} autoComplete="off">
                <h1>Вход</h1>
                <div className="form-div">
                    <label htmlFor="login">Логин</label>
                    <input
                        value={values.login}
                        onChange={handleChange}
                        id="login"
                        type="login"
                        placeholder="Введите логин"
                        onBlur={handleBlur}
                        className={errors.login && touched.login ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.login && touched.login && <p className="error">{errors.login}</p>}
                </div>
                <div className="form-div">
                    <label htmlFor="password">Пароль</label>
                    <input
                        id="password"
                        type="password"
                        placeholder="Введите пароль"
                        value={values.password}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={errors.password && touched.password ? "input-error" : ""}
                    />
                </div>
                <div>
                    {errors.password && touched.password && <p className="error">{errors.password}</p>}
                </div>
                <Button type="submit" variant="warning" id="button">Войти</Button>
            </form>
        </Container>
    )
}