import { useState } from 'react';
import GoodCard from '../components/GoodCard';
import goodsData from "../data/goods.js";

import "./style.css"

const categories = goodsData.goods
    .map(el => el.category)
    .filter((el, index, self) => self.indexOf(el) === index)

function Catalog() {
    const [category, setCategory] = useState("Отображать все")
    const [sortingProperty, setSortingProperty] = useState("added")

    return (
        <>
        <h1 style={{ textAlign: "center"}}>Меню</h1>
            <table>
                <th id="sort">
                    <ul>
                        <li
                            onClick={() => setCategory("Отображать все")}
                            style={{ cursor: "pointer" }}
                        >
                            Отображать все
                        </li>
                        {categories.map(el => (
                            <li
                                key={el}
                                onClick={() => setCategory(el)}
                                style={{ cursor: "pointer" }}
                            >
                                {el}
                            </li>
                        ))}
                    </ul>

                    <ul>
                        <li style={{ cursor: "pointer" }} onClick={() => setSortingProperty("added")}>Дата добавления</li>
                        <li style={{ cursor: "pointer" }} onClick={() => setSortingProperty("name")}>Название</li>
                        <li style={{ cursor: "pointer" }} onClick={() => setSortingProperty("price")}>Цена</li>
                    </ul>
                </th>
                <th>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                        {goodsData.goods
                            .filter(el => el.hasInStock)
                            .filter(el => category === "Отображать все" || category === el.category)
                            .sort((a, b) => {
                                if (a[sortingProperty] < b[sortingProperty]) return -1;
                                if (a[sortingProperty] === b[sortingProperty]) return 0;
                                return 1;
                            })
                            .map(good => (
                                <GoodCard 
                                    key={good.id} 
                                    id={good.id} 
                                    img={good.img} 
                                    name={good.name} 
                                    price={good.price} 
                                    follow
                                />
                            ))}
                    </div>
                </th>
            </table>
        </>
    );
}

export default Catalog;