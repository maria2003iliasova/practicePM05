import React, { Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./components/Header";
import Footer from "./components/Footer";

const Home = lazy(() => import ("./pages/Home"));
const About = lazy(() => import ("./pages/About"));
const Catalog = lazy(() => import ("./pages/Catalog"));
const Contacts = lazy(() => import ("./pages/Contacts"));
const Login = lazy(() => import ("./pages/Login"));
const Registr = lazy(() => import ("./pages/Registr"));
const Good = lazy(() => import ("./pages/Good"));
const Cart = lazy(() => import ("./pages/Cart"));
const Lk = lazy(() => import ("./pages/Lk"));

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<div>Loading...</div>}>
        <Header />
        <Routes>
          <Route path="/" exact element={<Home />} />
          <Route path="/about" exact element={<About />} />
          <Route path="/catalog" exact element={<Catalog />} />
          <Route path="/good/:id" exact element={<Good />} />
          <Route path="/cart" exact element={<Cart />} />
          <Route path="/contacts" exact element={<Contacts />} />
          <Route path="/login" exact element={<Login />} />
          <Route path="/registr" exact element={<Registr />} />
          <Route path="/lk" exact element={<Lk />} />
        </Routes>
        <Footer />
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
