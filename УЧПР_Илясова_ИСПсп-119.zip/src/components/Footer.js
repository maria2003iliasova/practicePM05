import React from "react";
import logo from "../images/logo.png";
import { Link } from "react-router-dom";
import Nav from 'react-bootstrap/Nav';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { IoMdCall } from "react-icons/io";
import { IoIosMail } from "react-icons/io";

import "./footer.css"

export default function Footer() {
    return (
        <>
            <Container fluid id="footer">
                <Row>
                    <Col>
                        <Nav defaultActiveKey="/" className="flex-column">
                            <Nav.Link as={Link} to="/" id="link">Главная</Nav.Link>
                            <Nav.Link as={Link} to="/about" id="link">О нас</Nav.Link>
                            <Nav.Link as={Link} to="/contacts" id="link">Где нас найти</Nav.Link>
                            <Nav.Link as={Link} to="/catalog" id="link">Меню</Nav.Link>
                        </Nav>
                    </Col>
                    <Col>
                        <Link to="/"><img src={logo} alt=" " /></Link>
                    </Col>
                    <Col>
                        <IoMdCall/>8 (800) 55-36-47<br/>
                        <IoMdCall/>8 (800) 56-43-98<br/>
                        <IoIosMail/>mia03.03@mail.ru<br/>
                        <IoIosMail/>delivery@mail.ru
                    </Col>
                </Row>
            </Container>
        </>
    );
}